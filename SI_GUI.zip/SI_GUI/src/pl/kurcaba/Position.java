package pl.kurcaba;

public class Position {
    public final int X,Y;

    Position(int x, int y)
    {
        this.X = x;
        this.Y = y;
    }
}
