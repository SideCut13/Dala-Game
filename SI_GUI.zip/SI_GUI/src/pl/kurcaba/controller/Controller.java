package pl.kurcaba.controller;

public class Controller {
}
